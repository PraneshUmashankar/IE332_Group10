Classes$Start_time <- substr(Classes$Start_time,1,nchar(Classes$Start_time)-3) #removes seconds from Start_time value, leaving hours:minutes
Classes$End_time <- substr(Classes$End_time,1,nchar(Classes$End_time)-3) #removes seconds from End_time value, leaving hours:minutes
f <- strsplit(Classes$End_time, ":")

f2=list()
for (i in 1:length(Classes$End_time)){
  f[[i]][2] <- (round(((as.numeric(f[[i]][2]) / 60)) / 0.5) * 0.5) * 60
  if (f[[i]][2] == 60){
    f[[i]][2] = "00"
    f[[i]][1] = as.numeric(f[[i]][1]) + 1
  }
  f2[i] <- paste(f[[i]][1], f[[i]][2], sep = ":")
}

Classes$End_time <- f2
