#Timepal_Scheduler <- function(student_email, targetd_semester){

require(RMySQL) #Establishes the RMySQL Package, which is needed to contact the database
require(xtable) #Establishes the Xtable Package, which is required to output the data in an HTML format

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))#Sets the R working directory to the folder in which this script is contained

student_email = 'kalebdunn@gmail.com'#Sample Student Email
target_semester = 'Spring 2021' #Sample target 

MainDB = dbConnect(MySQL(), user = 'g1117491', password = 'Group10', dbname="g1117491", host = "mydb.ics.purdue.edu") #Connects and Logs into Database

sql <- sprintf("SELECT c.Course_num, Weekday, Start_time, End_time FROM Classes AS c INNER JOIN Class_List AS l ON l.Course_num = c.Course_Num AND l.Semester = '%s' AND l.Email = '%s'", target_semester, student_email)
Classes <- fetch(dbSendQuery(MainDB, sql)) #The line above this Creates an SQL query, which is used by this line to retrieve the User's Class Schedule

sql <- sprintf("SELECT Obligation, Weekday, Start_time, End_time, Week, Daily, Weekdays, Weekends, Weekly, Biweekly FROM Obligations WHERE Semester = '%s' AND Email = '%s'", target_semester, student_email)
obligations <- fetch(dbSendQuery(MainDB, sql)) #The line above this Creates an SQL query, which is used by this line to retrieve the User's Obligations

sql <- sprintf("SELECT Priority_num, Priority_name, Priority_type, Priority_length, Day_pref, Start_time_pref, End_time_pref FROM Priorities WHERE Semester = '%s' AND Email = '%s' ORDER BY Priority_num", target_semester, student_email)
priorities <- fetch(dbSendQuery(MainDB, sql)) #The line above this Creates an SQL query, which is used by this line to retrieve the User's Priorities

sql <- sprintf("SELECT a.Course_num, Assignment_name, Assign_week, Assign_day, Assign_time, Due_week, Due_day, Due_time, Est_comp_time FROM Assignments AS a INNER JOIN Class_List AS l ON l.Semester = '%s' AND l.Course_num = a.Course_num AND l.email = '%s' ORDER BY Due_week ASC, Due_day ASC, Due_time ASC", target_semester, student_email)
Assignments <- fetch(dbSendQuery(MainDB, sql))#The line above this Creates an SQL query, which is used by this line to retrieve the User's Assignments

sql <- sprintf("SELECT Num_weeks FROM Semesters WHERE Semester = '%s'", target_semester)
weeknum <- fetch(dbSendQuery(MainDB, sql))[1,1]#The line above this Creates an SQL query, which is used by this line to retrieve the number of weeks in the target semester

output = data.frame(matrix(data=0, nrow=(weeknum-1), ncol = 4)) #Creates an empty Dataframe for use by the output
colnames(output) <- c("Email", "Week", "Semester", "Schedule") #Names the columns in the output of the algorithm

for (w in 1:(weeknum-1)){#Loop will run once for every week in a given semester
  week <- data.frame(matrix(data = NA, nrow=48, ncol=7, byrow=FALSE, dimnames = NULL)) #creates matrix
  colnames(week) <- c("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday") #names columns after day of week
  rownames(week) <- c("00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30" ,"04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00" , "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30") #names rows after time slots
  #The above lines create an empty array to represent a normal week, then names the columns for the days and the rows for every half-hour increment in a day
  
  source("Class_Assignment.R") #Runs Class Assignment Program
  source("Obligation_Assignment.R") #Runs Obligation Assignment Program
  source("Assignments_Assignment.R") #Runs the Assignment Scheduler Program
  source("Priority_Assignment.R") #Runs Priority Assignment Program
  
  for(d in 1:7){ #Fills in the remaining time blocks in the array as "unstructured"
    for (t in 1:48){
      if (is.na(week[t,d] == TRUE)){
        week[t,d] <- "Unstructured Time"
      }
    }
  }
  output[w,1] = student_email #These 4 lines create column names for the output data frame, to ensure compatibility with the database
  output[w,2] = w
  output[w,3] = target_semester
  output[w,4] = print(xtable(week), type = "html", print.results = FALSE) #converts output to html tables and inserts into output database
}

dbWriteTable(MainDB, "Schedule", output, append = TRUE, row.names = FALSE) #Writes completed schedule to the database using html tables
dbWriteTable(MainDB, "Priorities_out", p_t_spent, append = TRUE) #writes out time spent per priority (for machine learning)
dbDisconnect(MainDB) #Disconnects algorithm from Database
#}