start.time <- Sys.time()
require(RMySQL)
require(stats)

setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #Sets the R working directory to the folder in which this script is contained
#MainDB = dbConnect(MySQL(), user = 'g1117491', password = 'Group10', dbname="Group_10_Database", host = "mydb.itap.purdue.edu")

#sql <- sprintf("SELECT Obligation Name, Weekday, Start Time, End Time, Week Number FROM Obligations WHERE Email = %s ORDER BY Weekday, Start Time", student_email)
#obligations <- fetch(dbSendQuery(Group_10_Database, sql,n=-1)
obligations <- read.csv("Sample_data.csv", header = TRUE) #TEST DATA in .CSV FILE

#sql <- sprintf("SELECT Priority Number, Priority Name, Priority Length FROM Priorities WHERE Email = %s ORDER BY Priority Number", student_email)
#Priorities <- fetch(dbSendQuery(Group_10_Database, sql,n=-1)
priorities <- read.csv("Sample Priorities.csv", header=TRUE) #Sample Priority Data in .CSV

weeknum = 16
breakweek = 8
for (w in 1:weeknum){
  
  week <- data.frame(matrix(data = NA, nrow=48, ncol=7, byrow=FALSE, dimnames = NULL)) #creates matrix
  colnames(week) <- c("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday") #names columns after day of week
  rownames(week) <- c("00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30" ,"04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00" , "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30") #names rows after time slots
  
  if (w != breakweek & w != weeknum){
    source("Obligation_Assignment.R") #Runs Obligation Assignment Program
  }
  
  source("Priority_Assignment.R") #Runs Priority Assignment Program
  
  assign(paste0("Week_", w), week) #Assigns individual week names

}
end.time <- Sys.time()
print(end.time - start.time)
