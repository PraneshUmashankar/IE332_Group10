placeholder

for (j in 2:6) {
  for (i in 32:48) {
    if (is.na(week[i,j]) == TRUE & (is.na(priorities[k,3]) == FALSE)) {
      week[i,j] <-  priorities[k,2]
      plength = plength + .5
      
      if ((plength > priorities[k,3]) == TRUE) {
        plength = 0
        k = k + 1
      }
    }
  }
}