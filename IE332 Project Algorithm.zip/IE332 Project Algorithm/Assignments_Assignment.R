if(w==1){
  source("Assignments_Formatting.R") #Format Assignments time data for compatibility
}

drange = NA #base parameters for counter variables
trange = NA
Ass_time_week <- round((Assignments$Est_comp_time / (Assignments$Due_week-Assignments$Assign_week)) / .5) * .5 #ensure even amount of time/week spent on every assignment

for (a in 1:length(Assignments$Assignment_name)){ #Ensures that assignments are not being scheduled outside of valid date range
  if ((w >= Assignments$Assign_week[[a]] && w <= Assignments$Due_week[[a]])){
    if(Ass_time_week[a] > 0){
      if (w == Assignments$Assign_week[[a]]){
        drange = match(Assignments$Assign_day[[a]], colnames(week)) : 7
      } else if (w == Assignments$Due_week[[a]]){
        drange = 1 : match(Assignments$Due_day[[a]], colnames(week))
      } else{
        drange = 1:7
        trange = 1:48
      }
      if (is.na(drange) == FALSE && is.na(trange)==FALSE){ #ensures that assignment times are valid before scheduling
        for (d in drange){
          if(d == match(Assignments$Assign_day[[a]], colnames(week))){ #Sets time range for scheduling based upon due dates and times
            trange = match(Assignments$Assign_time[[a]], rownames(week)) : 48
          } else if (d == match(Assignments$Due_day[[a]], colnames(week))){
            trange = 1 : match(Assignments$Due_time[[a]], rownames(week))
          }
          for (t in trange){
            if((is.na(week[t,d]) == TRUE) && Ass_time_week[a] > 0){ #Schedules assignment work, wihout overwriting previous entries and without overloading the student
              week[t,d] <- sprintf("Work on %s for %s", Assignments$Assignment_name[[a]], Assignments$Course_num[[a]])
              Ass_time_week[a] <- Ass_time_week[a] - 0.5 #removes time from weekly counter.
            }
          }
        }
      }
    }
  } 
}