Assignments$Due_time <- substr(Assignments$Due_time,1,nchar(Assignments$Due_time)-3) #Removes seconds from time columns
Assignments$Assign_time <- substr(Assignments$Assign_time,1,nchar(Assignments$Assign_time)-3) 

Assignments$Course_num <- substr(Assignments$Course_num,1,nchar(Assignments$Course_num)-3) 

f <- strsplit(Assignments$Assign_time, ":") #Separates Minutes From hours for processing 
f2 <- strsplit(Assignments$Due_time, ":")

f3=list() #empty lists to hold reformatted time data
f4=list()

for (i in 1:length(Assignments$Assign_time)){
  f[[i]][2] <- (round(((as.numeric(f[[i]][2]) / 60)) / 0.5) * 0.5) * 60 #Rounds minutes slot to nearest half-hour
  if (f[[i]][2] == 60 || f[[i]][2] == 0){
    if (f[[i]][2] == 60){
      f[[i]][1] = as.numeric(f[[i]][1]) + 1 #Makes sure hours update properly if rounding up from >45 minutes
    }
    f[[i]][2] = "00" #format friendly to assignment code
  }
  f3[i] <- paste(f[[i]][1], f[[i]][2], sep = ":") #Pastes formatted time to empty list
  if (f3[i] == "24:00"){
    f3[i] <- "00:00" #rolls over to midnight of next day (and potentially week) as necessary
    if (Assignments$Assign_day[[i]] == 'Sunday'){
      Assignments$Assign_day[[i]] = 'Monday'
    } else if (Assignments$Assign_day[[i]] == 'Monday'){
      Assignments$Assign_day[[i]] = 'Tuesday'
    } else if (Assignments$Assign_day[[i]] == 'Tuesday'){
      Assignments$Assign_day[[i]] = 'Wednesday'
    } else if (Assignments$Assign_day[[i]] == 'Wednesday'){
      Assignments$Assign_day[[i]] = 'Thursday'
    } else if (Assignments$Assign_day[[i]] == 'Thursday'){
      Assignments$Assign_day[[i]] = 'Friday'
    } else if (Assignments$Assign_day[[i]] == 'Friday'){
      Assignments$Assign_day[[i]] = 'Saturday'
    } else if (Assignments$Assign_day[[i]] == 'Saturday'){
      Assignments$Assign_day[[i]] = 'Sunday'
      Assignments$Assign_week[[i]] = Assignments$Assign_week[[i]] + 1
    }
  }
}

Assignments$Assign_time <- f3 #Pastes reformatted times to data frame

for (i in 1:length(Assignments$Due_time)){
  f2[[i]][2] <- (round(((as.numeric(f2[[i]][2]) / 60)) / 0.5) * 0.5) * 60 #Rounds minutes slot to nearest half-hour
  if (f2[[i]][2] == 60 || f2[[i]][2] == 0){
    if (f2[[i]][2] == 60){
      f2[[i]][1] = as.numeric(f2[[i]][1]) + 1 #Makes sure hours update properly if rounding up from >45 minutes
    }
    f2[[i]][2] = "00" #format friendly to assignment code
  }
  f4[i] <- paste(f2[[i]][1], f2[[i]][2], sep = ":") #Pastes formatted time to empty list
  if (f4[i] == "24:00"){
    f4[i] <- "00:00" #rolls over to midnight of next day (and potentially week) as necessary
    if (Assignments$Due_day[[i]] == 'Sunday'){
      Assignments$Due_day[[i]] = 'Monday'
    } else if (Assignments$Due_day[[i]] == 'Monday'){
      Assignments$Due_day[[i]] = 'Tuesday'
    } else if (Assignments$Due_day[[i]] == 'Tuesday'){
      Assignments$Due_day[[i]] = 'Wednesday'
    } else if (Assignments$Due_day[[i]] == 'Wednesday'){
      Assignments$Due_day[[i]] = 'Thursday'
    } else if (Assignments$Due_day[[i]] == 'Thursday'){
      Assignments$Due_day[[i]] = 'Friday'
    } else if (Assignments$Due_day[[i]] == 'Friday'){
      Assignments$Due_day[[i]] = 'Saturday'
    } else if (Assignments$Due_day[[i]] == 'Saturday'){
      Assignments$Due_day[[i]] = 'Sunday'
      Assignments$Due_week[[i]] = Assignments$Due_week[[i]] + 1
    }
  }
}
Assignments$Due_time <- f4 #Pastes reformatted times to data frame