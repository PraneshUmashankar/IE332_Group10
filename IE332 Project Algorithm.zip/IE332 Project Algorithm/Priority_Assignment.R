i=1
j=1
k=1
plength=0
Slot_empty=0
P_times <- data.frame(matrix(data=NA, nrow=length(priorities[,1]), ncol=1))


if (priorities[k,4] = "Weekday") {
  jrange <- 2:6
}

if (priorities[k,5] = "Morning") {
  irange = 0:13
}

for (j in jrange) {
  for (i in irange) {
    if (is.na(week[i,j]) == TRUE)
      Slot_empty = Slot_empty + 1
  }
}

for (k in 1:length(priorities[,1])) {
  P_times[k,1] <- Slot_empty * priorities[k,3]
}

  

