i=1 #baseline counter variable parameters
j=1
availtime = 0
p_times <- data.frame(0)
p_t_spent <- data.frame(matrix(data=0, nrow=1, ncol = 7)) #creates and names empty dataframe to track time per priority
colnames(p_t_spent) <- c("Email", "Semester", "Social_time", "Study_time", "Free_time", "Exercise_time", "Other_time")
p_t_spent$Email <- student_email
p_t_spent$Semester <- target_semester

trange = 1:48 #basic counter parameters
drange = 1:7

if(w==1){ #ensures correct data format
  priorities$Start_time_pref <- substr(priorities$Start_time_pref,1,nchar(priorities$Start_time_pref)-3) #Removes seconds from time columns
  priorities$End_time_pref <- substr(priorities$End_time_pref,1,nchar(priorities$End_time_pref)-3) 
}


for (j in drange) { #Counts available time slots remaining in week
  for (i in trange) {
    if (is.na(week[i,j]) == TRUE)
      availtime = availtime + 0.5
  }
}

p_times = round((availtime * priorities$Priority_length) / .5) * .5 #rounds priority times and ensures that correct hours are avaliable
if(sum(p_times) < availtime){
  while(sum(p_times) < availtime){
    a <- match(min(priorities$Priority_num), priorities$Priority_num) #adds time to highest priorities if extra time available
    p_times[a] = p_times[a] + 0.5
  }
} else if (sum(p_times) > availtime){
  while(sum(p_times > availtime)){
    a <- match(max(priorities$Priority_num), priorities$Priority_num) #removes time from lowest priority if not enough time available
    p_times[a] = p_times[a] - 0.5
  }
}

for (a in 1:length(priorities$Priority_type)){ #THESE LINES count the time spent per SEMESTER by priority type (for ML)
  if(!is.na(match(priorities$Priority_type[[a]], "social time"))){
      p_t_spent$Social_time[[1]] <- p_t_spent$Social_time[[1]] + p_times[a]
      
  } else if(!is.na(match(priorities$Priority_type[[a]], "study time"))){
      p_t_spent$Study_time[[1]] <- p_t_spent$Study_time[[1]] + p_times[a]
      
  } else if(!is.na(match(priorities$Priority_type[[a]], "free time"))){
      p_t_spent$Free_time[[1]] <- p_t_spent$Free_time[[1]] + p_times[a]
      
  } else if(!is.na(match(priorities$Priority_type[[a]], "exercise time"))){
      p_t_spent$Exercise_time[[1]] <- p_t_spent$Exercise_time[[1]] + p_times[a]
  } else if(!is.na(match(priorities$Priority_type[[a]], "other time"))){
    p_t_spent$other_time[[1]] <- p_t_spent$other_time[[1]] + p_times[a]
  }
}

for (p in 1:length(priorities$Priority_name)){ #resets scheduling parameters based on conditions set by user
  drange <- 1:7
  trange <- 1:48
  if (is.na(priorities$Day_pref[[p]]) == FALSE){
    if (priorities$Day_pref[[p]] == "Weekend"){
      drange = c(1,7)
    }
    if(priorities$Day_pref[[p]] == "Weekday"){
      drange = 2:6
    }
  }
  if ((is.na(priorities$Start_time_pref[[p]]) == FALSE) && is.na(priorities$End_time_pref[[p]]) == FALSE){ #sets time range based on user constraints
    trange <- match(priorities$Start_time_pref[[p]], rownames(week)) : match(priorities$End_time_pref[[p]], rownames(week))
  }
  if (is.na(priorities$Start_time_pref[[p]]) == FALSE){
    trange = match(priorities$Start_time_pref[[p]], rownames(week)) : 48
  }
  if (is.na(priorities$End_time_pref[[p]]) == FALSE){
    trange = 1 : match(priorities$End_time_pref[[p]], rownames(week))
  }
  
  for(d in drange){
    for(t in trange){ #schedules priorities base on above-defined constraints, moving on when all priority hours have been scheduled
      if(is.na(week[t,d]) == TRUE && p_times[p] > 0){
        week[t,d] <- priorities$Priority_name[[p]]
        p_times[[p]] = p_times[[p]] - 0.5
      }
    }
  }
}