i=1
j=1
k=1
plength=0
Slot_empty=0
P_times <- data.frame(0)
irange = 1:48
jrange = 1:7

for (j in jrange) {
  for (i in irange) {
    if (is.na(week[i,j]) == TRUE)
      Slot_empty = Slot_empty + 1
  }
}

for (k in 1:length(priorities[,1])) {
  P_times[k] <- round((Slot_empty * priorities[k,3])/.5)*.5
}



for (k in 1:length(priorities[,1])){
  if (priorities[k,4] == "Weekday") {
    jrange <- 2:6
  }
  
  if (priorities[k,4] == "Weekend") {
    jrange <- c(1,7)
  }
  
  
  if (priorities[k,5] == "Early Morning") {
    irange = 1:16
  }
  
  if (priorities[k,5] == "Late Morning"){
    irange = 17:24
  }
  
  if (priorities[k,5] == "Afternoon"){
    irange = 25:38
  }
  
  if (priorities[k,5] == "Evening") {
    irange = 39:48
  }
 
  for (j in jrange) {
    for (i in irange) {
      if (is.na(week[i,j]) == TRUE) {
        week[i,j] <-  priorities[k,2]
        plength = plength + .5
        
        if ((plength >= P_times[k]) == TRUE) {
          plength = 0
        }
      }
    }
  } 
}
  