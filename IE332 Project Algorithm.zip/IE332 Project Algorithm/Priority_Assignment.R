i=1
j=1
availtime = 0
p_times <- data.frame(0)
p_t_spent <- data.frame(0)
trange = 1:48
drange = 1:7

if(w==1){
  priorities$Start_time_pref <- substr(priorities$Start_time_pref,1,nchar(priorities$Start_time_pref)-3) #Removes seconds from time columns
  priorities$End_time_pref <- substr(priorities$End_time_pref,1,nchar(priorities$End_time_pref)-3) 
}




for (j in drange) {
  for (i in trange) {
    if (is.na(week[i,j]) == TRUE)
      availtime = availtime + 0.5
  }
}
p_times = round((availtime * priorities$Priority_length) / .5) * .5
if(sum(p_times) < availtime){
  while(sum(p_times) < availtime){
    a <- match(min(priorities$Priority_num), priorities$Priority_num)
    p_times[a] = p_times[a] + 0.5
  }
} else if (sum(p_times) > availtime){
  while(sum(p_times > availtime)){
    a <- match(max(priorities$Priority_num), priorities$Priority_num)
    p_times[a] = p_times[a] - 0.5
  }
}
assign(paste0("P_spent_", w), p_times)
for (p in 1:length(priorities$Priority_name)){
  drange <- 1:7
  trange <- 1:48
  if (is.na(priorities$Day_pref[[p]]) == FALSE){
    if (priorities$Day_pref[[p]] == "Weekend"){
      drange = c(1,7)
    }
    if(priorities$Day_pref[[p]] == "Weekday"){
      drange = 2:6
    }
  }
  if ((is.na(priorities$Start_time_pref[[p]]) == FALSE) && is.na(priorities$End_time_pref[[p]]) == FALSE){
    trange <- match(priorities$Start_time_pref[[p]], rownames(week)) : match(priorities$End_time_pref[[p]], rownames(week))
  }
  if (is.na(priorities$Start_time_pref[[p]]) == FALSE){
    trange = match(priorities$Start_time_pref[[p]], rownames(week)) : 48
  }
  if (is.na(priorities$End_time_pref[[p]]) == FALSE){
    trange = 1 : match(priorities$End_time_pref[[p]], rownames(week))
  }
  
  for(d in drange){
    for(t in trange){
      if(is.na(week[t,d]) == TRUE && p_times[p] > 0){
        week[t,d] <- priorities$Priority_name[[p]]
        p_times[[p]] = p_times[[p]] - 0.5
      }
    }
  }
}