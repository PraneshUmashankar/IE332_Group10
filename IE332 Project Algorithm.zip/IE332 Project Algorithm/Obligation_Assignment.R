  for (i in 1:length(obligations[,1])) { #for loop to fill in week data frame
    if (w == obligations[i,5] | obligations[i,5] == ""){
      week[(match(obligations[i,2], rownames(week)):match(obligations[i,3], rownames(week))), match(obligations[i,4], colnames(week))] <- obligations[i,1]
    }
  }

  #obligations$End_time <- substr(obligations$End_time,1,nchar(obligations$End_time)-3)