if(w==1){
  obligations$End_time <- substr(obligations$End_time,1,nchar(obligations$End_time)-3) #Ensures correct Data Format
  obligations$Start_time <- substr(obligations$Start_time,1,nchar(obligations$Start_time)-3) 
  
  f <- strsplit(obligations$Start_time, ":")
  f2 <- strsplit(obligations$End_time, ":")
  
  f3=list() #empty list variables for use in pasting into array
  f4=list()
  for (i in 1:length(obligations$Start_time)){
    f[[i]][2] <- (round(((as.numeric(f[[i]][2]) / 60)) / 0.5) * 0.5) * 60 #round to nearest half-hour for start time
    if (f[[i]][2] == 60 || f[[i]][2] == 0){
      if (f[[i]][2] == 60){
        f[[i]][1] = as.numeric(f[[i]][1]) + 1
      }
      f[[i]][2] = "00"
    }
    f3[i] <- paste(f[[i]][1], f[[i]][2], sep = ":")
    if (f3[i] == "24:00"){
      f3[i] <- "23:30"
    }
  }
  
  for (i in 1:length(obligations$End_time)){
    f2[[i]][2] <- (round(((as.numeric(f2[[i]][2]) / 60)) / 0.5) * 0.5) * 60 #round to nearest half-hour for end time
    if (f2[[i]][2] == 60 || f2[[i]][2] == 0){
      if (f2[[i]][2] == 60){
        f2[[i]][1] = as.numeric(f2[[i]][1]) + 1
      }
      f2[[i]][2] = "00"
    }
    f4[i] <- paste(f2[[i]][1], f2[[i]][2], sep = ":")
    if (f4[i] == "24:00"){
      f4[i] <- "23:30"
    }
  }
  obligations$Start_time <- f3 #paste reformatted lists into respective places in dataframe
  obligations$End_time <- f4
}

for (o in 1:length(obligations$Obligation)){ #ensures correct date and time frame for assignment of obligations
  if(obligations$Week[[o]] == w){
    d <- match(obligations$Weekday[[o]], colnames(week))
    t <- head(match(obligations$Start_time[[o]], rownames(week)) : match(obligations$End_time[[o]], rownames(week)), -1)
    
    
    if(obligations$Daily[[o]] == 1){
      d <- 1:7
    }
    if(obligations$Weekdays[[o]] == 1){
      d <- 2:6
    }
    if(obligations$Weekends[[o]] == 1){
      d <- c(1,7)
    }
    if(obligations$Weekly[[o]] == 1){
      obligations$Week[[o]] = obligations$Week[[o]] + 1
    }
    if(obligations$Biweekly[[o]] == 1){
      obligations$Week[[o]] = obligations$Week[[o]] + 2
    }
    
    week[t,d] <- obligations$Obligation[[o]] #assigns obligations subject to earlier constraints
    
  }
} 