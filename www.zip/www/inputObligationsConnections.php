<?php


$servername = "mydb.itap.purdue.edu";
$username = "g1117491";
$password2= "Group10";
$dbname = "g1117491";
// Create connection



$conn = mysqli_connect($servername, $username, $password2,$dbname);

$Email = $_POST['Email'];
$Obligation = $_POST['Obligation'];
$Weekday = $_POST['Weekday'];
$Start_time = $_POST['Start_time'];
$End_time = $_POST['End_time'];
$Week = $_POST['Week'];
$Semester = $_POST['Semester'];
$Daily = $_POST['Daily'];
$Weekdays = $_POST['Weekdays'];
$Weekends = $_POST['Weekends'];
$Weekly = $_POST['Weekly'];
$Biweekly = $_POST['Biweekly'];
{

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
else
{

	$sql = "INSERT INTO Obligations(`Email`, `Obligation`, `Weekday`, `Start_time`,`End_time`, `Week`, `Semester`, `Daily`,`Weekdays`, `Weekends`, `Weekly`, `Biweekly`) VALUES('$Email','$Obligation','$Weekday','$Start_time','$End_time','$Week','$Semester','$Daily','$Weekdays','$Weekends','$Weekly','$Biweekly')";


if ($conn->query($sql) === TRUE) {
	header("Location: studentDataInput.html");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}}

mysqli_close($conn);

?>