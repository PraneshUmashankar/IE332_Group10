

<?php


$servername = "mydb.itap.purdue.edu";
$username = "g1117491";
$password = "Group10";
$dbname = "g1117491";
// Create connection



$conn = mysqli_connect($servername, $username, $password,$dbname);

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$password = $_POST['password2'];
$email = $_POST['email'];




{
	$sql = "INSERT INTO Admins(`adminfname`, `adminlname`, `adminemail`, `adminpass`) VALUES('$fname','$lname','$email','$password')";



if ($conn->query($sql) === TRUE) {
     header("Location: adminhome.html");
} else {
    echo "Error: Invaild input please try again" ;
}}
mysqli_close($conn);

?>

