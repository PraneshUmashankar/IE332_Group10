<?php

$servername = "mydb.itap.purdue.edu";
$username = "g1117491";
$password = "Group10";
$dbname = "g1117491";
// Create connection



$conn = mysqli_connect($servername, $username, $password,$dbname);



 $email=$_POST['email'];
 $pass=$_POST['password2'];


$sql ="SELECT (*) FROM Admins WHERE adminemail = '$email' AND adminpass = '$password2')";
$result = mysqi_query($conn, $sql); 
	mysqli_close($conn);

  ?>
  
  