<?php


$servername = "mydb.itap.purdue.edu";
$username = "g1117491";
$password2= "Group10";
$dbname = "g1117491";
// Create connection



$conn = mysqli_connect($servername, $username, $password2,$dbname);

$Coursenum = $_POST['Course_num'];
$Profemail = $_POST['Prof_email'];
$Esttime = $_POST['Est_time'];
$Semester = $_POST['Semester'];


{

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
else
{

	$sql = "INSERT INTO Courses(`Course_num`, `Prof_email`, `Est_time`, `Semester`) VALUES('$Coursenum','$Profemail','$Est_time','$Semester')";


if ($conn->query($sql) === TRUE) {
	header("Location: professorDataInput.html");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}}

mysqli_close($conn);

?>

