<?php


$servername = "mydb.itap.purdue.edu";
$username = "g1117491";
$password2= "Group10";
$dbname = "g1117491";
// Create connection



$conn = mysqli_connect($servername, $username, $password2,$dbname);

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$password = $_POST['password2'];
$email = $_POST['email'];


{

	$sql = "INSERT INTO Students(`fname`, `lname`, `email`, `password`) VALUES('$fname','$lname','$email','$password')";

if ($conn->query($sql) === TRUE) {
     header("Location: studentDataInput.html");
} else {
    echo "Error: Invaild input please try again" ;
}}
mysqli_close($conn);

?>

