## This function creates and stores a jpeg file of the visualization of the GPA neural network for use in our website
  library(nnet)
  source("GPAregress.R")
jpeg('GPAnetwork')
plot(GPARegression())
dev.off()
return()