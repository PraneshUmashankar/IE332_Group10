HappinessRegression <-function(){
  ## This function generates machine learning regressions of student GPA and student Happiness using neural network technology
  ## No input is required for the function to run, and it trains on all past semester data available in the database 
  library(nnet)
  library(RMySQL)
  # Creates connection to database and ensures connection ends when session ends
  con <- dbConnect(MySQL(),user = "g1117491", password = "Group10", dbname = "g1117491", host = "mydb.ics.purdue.edu")
  # Pulls all data for regression
  surveyquery <- dbSendQuery(con, "SELECT Survey.Happiness, Survey.GPA, Survey.Email, Survey.Semester, sum(Courses.Est_time) + sum(Assignments.Est_comp_time) AS Semester_Difficulty, Priorities_out.Social_time, Priorities_out.Study_time, Priorities_out.Free_time, Priorities_out.Exercise_time, Priorities_out.Other_time
FROM Survey JOIN Class_List ON Survey.Semester = Class_List.Semester AND Survey.Email = Class_List.Email 
JOIN Courses ON Class_List.Course_num = Courses.Course_num AND Class_List.Semester = Courses.Semester 
JOIN Assignments ON Assignments.Course_num = Courses.Course_num 
JOIN Priorities_out ON Priorities_out.Email = Survey.Email AND Priorities_out.Semester = Survey.Semester
GROUP BY Survey.Email, Survey.Semester
ORDER BY Survey.Email, Survey.Semester")
  data <- fetch(surveyquery)
  
  # At this point, all data has been pulled from the database and combined into one large data frame for processing
  
  #These two lines create the neural networks for regressing GPA and Happiness values and perform those regressions
  GPAregress <- nnet(class.ind(data$GPA) ~ data$Semester_Difficulty + data$Social_time + data$Study_time + data$Free_time + data$Exercise_time + data$Other_time, data=data, size = 2)
  Happinessregress <- nnet(class.ind(data$Happiness) ~ data$Semester_Difficulty + data$Social_time + data$Study_time + data$Free_time + data$Exercise_time + data$Other_time, data=data, size = 2)
  
  return(Happinessregress)
  }