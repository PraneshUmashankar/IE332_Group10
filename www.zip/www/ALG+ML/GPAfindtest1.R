
email <- "kalebdunn@gmail.com"
semester <- "Spring 2021"
library(nnet)
library(RMySQL)
# Creates connection to database and ensures connection ends when session ends
con <- dbConnect(MySQL(),user = "g1117491", password = "Group10", dbname = "g1117491", host = "mydb.ics.purdue.edu")



query <- sprintf("SELECT Class_List.Email, Class_List.Semester, sum(Courses.Est_time) + sum(Assignments.Est_comp_time) AS Semester_Difficulty, Priorities_out.Social_time, Priorities_out.Study_time, Priorities_out.Free_time, Priorities_out.Exercise_time, Priorities_out.Other_time
  FROM Class_List JOIN Courses ON Class_List.Course_num = Courses.Course_num AND Class_List.Semester = Courses.Semester
  JOIN Assignments ON Assignments.Course_num = Courses.Course_num
  JOIN Priorities_out ON Priorities_out.Email = Class_List.Email AND Priorities_out.Semester = Class_List.Semester
  HAVING Class_List.Email = '%s' AND Class_List.Semester ='%s'", email, semester)

studata <- dbSendQuery(con, query)

source("GPAregress.R")
pred_GPA <- predict(GPARegression(), studata, type="class")

dbDisconnect(con)
return(pred_GPA)
