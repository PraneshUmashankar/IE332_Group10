  ## This function creates and stores a jpeg file of the visualization of the Happiness neural network for use in our website
  library(nnet)
  source("Happinessregress.R")
  jpeg('Happinessnetwork')
  plot(HappinessRegression())
  dev.off()
  return()
