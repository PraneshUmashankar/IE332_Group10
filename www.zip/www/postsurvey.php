<?php


$servername = "mydb.itap.purdue.edu";
$username = "g1117491";
$password2= "Group10";
$dbname = "g1117491";
// Create connection



$conn = mysqli_connect($servername, $username, $password2,$dbname);

$semester = $_POST['Semester'];
$happiness = $_POST['happiness'];
$gpa = $_POST['gpa'];
$email = $_POST['email'];


{

	$sql = "INSERT INTO Survey(`Email`, `Semester`, `GPA`, `Happiness`) VALUES('$email','$semester','$gpa','$happiness')";

     header("Location: studentDataInput.html");
	 
if ($conn->query($sql) === TRUE) {

} else {
    echo "Error: Invaild input please try again" ;
}}
mysqli_close($conn);

?>