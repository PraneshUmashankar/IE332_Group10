<?php


$servername = "mydb.itap.purdue.edu";
$username = "g1117491";
$password2= "Group10";
$dbname = "g1117491";
// Create connection



$conn = mysqli_connect($servername, $username, $password2,$dbname);

$Course_num = $_POST['Course_num'];
$Assignment = $_POST['Assignment_name'];
$Semester = $_POST['Semester'];
$Assign_week = $_POST['Assign_week'];
$Assign_day = $_POST['Assign_day'];
$Assign_time = $_POST['Assign_time'];
$Due_week = $_POST['Due_week'];
$Due_day = $_POST['Due_day'];
$Due_time = $_POST['Due_time'];
$Est_comp_time = $_POST['Est_comp_time'];
$Repeat = $_POST['Repeat'];

{

if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
else
{
	if ($Repeat = "Weekly") {
		for($x = Due_week; $x <= 16; $x++) {
	$sql = "INSERT INTO Assignments(`Course_num`,`Assignment_name`, `Semester`, `Assign_week`, `Assign_day`, `Assign_time`, `Due_week`, `Due_day`, `Due_time`, `Est_comp_time`) VALUES('$Course_num','$Assignment','$Semester','$Assign_week','$Assign_day', '$Assign_time', '$Due_week', '$Due_day', '$Due_time', '$Est_comp_time')";
		}
	}
	elseif ($Repeat = "Biweekly") {
		for($x = Due_week; $x <= 16; $x+=2) {
	$sql = "INSERT INTO Assignments(`Course_num`,`Assignment_name`, `Semester`, `Assign_week`, `Assign_day`, `Assign_time`, `Due_week`, `Due_day`, `Due_time`, `Est_comp_time`) VALUES('$Course_num','$Assignment','$Semester','$Assign_week','$Assign_day', '$Assign_time', '$Due_week', '$Due_day', '$Due_time', '$Est_comp_time')";
		}
	}
	else{
	$sql = "INSERT INTO Assignments(`Course_num`,`Assignment_name`, `Semester`, `Assign_week`, `Assign_day`, `Assign_time`, `Due_week`, `Due_day`, `Due_time`, `Est_comp_time`) VALUES('$Course_num','$Assignment','$Semester','$Assign_week','$Assign_day', '$Assign_time', '$Due_week', '$Due_day', '$Due_time', '$Est_comp_time')";
	}


if ($conn->query($sql) === TRUE) {
	header("Location: professorDataInput.html");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}}

mysqli_close($conn);

?>

